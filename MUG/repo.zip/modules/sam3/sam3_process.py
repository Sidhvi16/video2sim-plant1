#!/usr/bin/env python3
# =============================================================================
#  sam3_process.py  —  SAM2.1 drop-in replacement for SAM3
#
#  Preserves the full original interface:
#    - Same env vars (SCENE_NAME, DATA_ROOT, SAM3_MIN_SCORE,
#      SAM3_MIN_FRAME_DURATION)
#    - Same prompts.txt input (text prompts, one per line)
#    - Same instance_mask/ output structure and filename convention
#    - Same painter's-algorithm compositing
#    - Same per-prompt stats table
#    - Same min_score / min_frame_duration filtering
#
#  SAM2.1 does not support open-vocabulary text prompts natively.
#  We use CLIP (ViT-B/32, ~340 MB, no gating) to rank candidate boxes
#  produced by SAM2's automatic mask generator, then feed the top-scoring
#  box per prompt into the video propagation predictor.
#
#  Weights used:
#    sam2.1_hiera_large.pt  — from HF cache (already downloaded)
#    ViT-B/32               — downloaded on first run, cached by CLIP
# =============================================================================

import os
import re
import json
import torch
import numpy as np
from PIL import Image
from pathlib import Path
from collections import Counter, defaultdict

# ── SAM2 ─────────────────────────────────────────────────────────────────────
from sam2.build_sam import build_sam2, build_sam2_video_predictor
from sam2.automatic_mask_generator import SAM2AutomaticMaskGenerator

# ── CLIP (open-vocabulary prompt matching) ───────────────────────────────────
try:
    import clip
except ImportError:
    raise ImportError(
        "openai-clip is required. Install with:\n"
        "  pip install git+https://github.com/openai/CLIP.git"
    )

# =============================================================================
#  Configuration
# =============================================================================

# Absolute path to the cached SAM2.1 checkpoint
_CHECKPOINT = (
    "/home/crajashekhar/cup1/data/cache/sam3/hub/"
    "models--facebook--sam2.1-hiera-large/snapshots/"
    "665f8e2ad61cf5f53d65644ff27c8ee525124610/"
    "sam2.1_hiera_large.pt"
)

# Model config shipped inside the sam2 package
_MODEL_CFG = "configs/sam2.1/sam2.1_hiera_l.yaml"

# How many candidate masks to generate per reference frame for prompt matching
_AMG_POINTS_PER_SIDE = 64


def get_config():
    scene = os.environ["SCENE_NAME"]
    data_root = Path(os.environ["DATA_ROOT"])
    return {
        "scene": scene,
        "img_dir": data_root / scene / "images",
        "out_dir": data_root / scene / "instance_mask",
        "min_score": float(os.environ["SAM3_MIN_SCORE"]),
        "min_dur": float(os.environ["SAM3_MIN_FRAME_DURATION"]) / 100.0,
        "prompts": [
            p.strip()
            for p in Path("prompts.txt").read_text().splitlines()
            if p.strip()
        ],
        "device": "cuda",
    }


# =============================================================================
#  CLIP-based prompt → bounding box matching
# =============================================================================

def load_clip(device):
    model, preprocess = clip.load("ViT-B/32", device=device)
    model.eval()
    return model, preprocess


@torch.no_grad()
def match_prompts_to_boxes(
    ref_frame: Image.Image,
    prompts: list[str],
    amg_masks: list[dict],
    clip_model,
    clip_preprocess,
    device: str,
    min_score: float,
) -> dict[str, dict]:
    """
    For each text prompt, find the AMG mask whose crop scores highest
    under CLIP similarity. Returns {prompt: {"box": xyxy, "score": float}}.
    Only entries with score >= min_score are included.
    """
    if not amg_masks:
        return {}

    text_tokens = clip.tokenize(prompts).to(device)
    text_feats = clip_model.encode_text(text_tokens)          # (P, D)
    text_feats = text_feats / text_feats.norm(dim=-1, keepdim=True)

    crops, valid_idx = [], []
    W, H = ref_frame.size
    for i, m in enumerate(amg_masks):
        x, y, bw, bh = m["bbox"]                             # xywh from AMG
        x1, y1 = max(0, x), max(0, y)
        x2, y2 = min(W, x + bw), min(H, y + bh)
        if x2 <= x1 or y2 <= y1:
            continue
        crop = ref_frame.crop((x1, y1, x2, y2))
        crops.append(clip_preprocess(crop))
        valid_idx.append(i)

    if not crops:
        return {}

    image_input = torch.stack(crops).to(device)
    image_feats = clip_model.encode_image(image_input)        # (N, D)
    image_feats = image_feats / image_feats.norm(dim=-1, keepdim=True)

    # similarity matrix: (P, N)
    sim = (text_feats @ image_feats.T).float().cpu().numpy()

    results = {}
    for p_idx, prompt in enumerate(prompts):
        best_n = int(np.argmax(sim[p_idx]))
        score = float(sim[p_idx][best_n])
        if score < min_score:
            continue
        mask_idx = valid_idx[best_n]
        x, y, bw, bh = amg_masks[mask_idx]["bbox"]
        results[prompt] = {
            "box": [x, y, x + bw, y + bh],                   # xyxy
            "score": score,
            "mask_idx": mask_idx,
        }
    return results


# =============================================================================
#  Mask compositing
# =============================================================================

def save_mask(filepath, masks, ids, id_map, shape):
    """Painter's Algorithm — largest mask drawn first (same as original)."""
    final = np.full(shape, 255, dtype=np.uint8)
    layers = [
        (m, id_map[int(oid)])
        for m, oid in zip(masks, ids)
        if int(oid) in id_map
    ]
    if layers:
        layers.sort(key=lambda x: np.count_nonzero(x[0]), reverse=True)
        for m, color in layers:
            final[m > 0] = color
    Image.fromarray(final).save(filepath)


# =============================================================================
#  Stats table (identical to original)
# =============================================================================

def print_stats_table(prompts, prompt_counts, id_to_prompt, valid_ids, total_frames):
    prompt_to_ids_all = defaultdict(list)
    for oid, p_text in id_to_prompt.items():
        prompt_to_ids_all[p_text].append(oid)

    print("\n" + "-" * 80)
    print(f"{'PROMPT':<25} | {'FRAMES':<12} | {'IDS (KEEP/ALL)':<15} | {'KEPT IDS'}")
    print("-" * 80)

    for p in prompts:
        p_count = prompt_counts.get(p, 0)
        all_ids = sorted(prompt_to_ids_all.get(p, []))
        kept_ids = [oid for oid in all_ids if oid in valid_ids]
        ratio_str = f"{len(kept_ids)}/{len(all_ids)}"
        ids_str = str(kept_ids) if len(kept_ids) < 8 else f"{len(kept_ids)} IDs"
        print(f"{p:<25} | {f'{p_count}/{total_frames}':<12} | {ratio_str:<15} | {ids_str}")

    print("-" * 80)


# =============================================================================
#  Main
# =============================================================================

def main():
    cfg = get_config()
    cfg["out_dir"].mkdir(parents=True, exist_ok=True)
    device = cfg["device"]

    # ── Load frames ───────────────────────────────────────────────────────────
    files = sorted(
        [f for f in cfg["img_dir"].iterdir() if not f.name.startswith(".")]
    )
    frames = [Image.open(f).convert("RGB") for f in files]
    h, w = frames[0].size[::-1]
    total_frames = len(frames)
    print(f"Loaded {total_frames} frames ({w}×{h})")

    # ── Build SAM2 automatic mask generator (used on reference frame only) ───
    print("Loading SAM2.1 checkpoint...")
    sam2_model = build_sam2(_MODEL_CFG, _CHECKPOINT, device=device)
    amg = SAM2AutomaticMaskGenerator(
        sam2_model,
        points_per_side=_AMG_POINTS_PER_SIDE,
    )

    # ── Load CLIP ─────────────────────────────────────────────────────────────
    print("Loading CLIP ViT-B/32...")
    clip_model, clip_preprocess = load_clip(device)

    # ── Use middle frame as reference for prompt matching ─────────────────────
    ref_idx = total_frames // 2
    ref_frame = frames[ref_idx]
    print(f"Generating AMG masks on reference frame {ref_idx}...")
    amg_masks = amg.generate(np.array(ref_frame))
    print(f"  {len(amg_masks)} candidate masks generated")

    # ── Match each text prompt to a bounding box via CLIP ────────────────────
    print("Matching prompts to masks via CLIP...")
    prompt_matches = match_prompts_to_boxes(
        ref_frame,
        cfg["prompts"],
        amg_masks,
        clip_model,
        clip_preprocess,
        device,
        cfg["min_score"],
    )

    if not prompt_matches:
        print("No prompts matched above score threshold. Exiting.")
        return

    for p, m in prompt_matches.items():
        print(f"  '{p}' → box {m['box']}  score={m['score']:.3f}")

    # ── Build SAM2 video predictor ────────────────────────────────────────────
    print("Building SAM2.1 video predictor...")
    predictor = build_sam2_video_predictor(_MODEL_CFG, _CHECKPOINT, device=device)

    # SAM2 video predictor expects a directory of JPEG/PNG frames
    # SAM2 requires integer-only filenames — symlink frames into a temp dir
    import tempfile, shutil
    tmp_dir = Path(tempfile.mkdtemp())
    for i, f in enumerate(files):
        (tmp_dir / f"{i:06d}{f.suffix}").symlink_to(f.resolve())
    img_dir_str = str(tmp_dir)

    with torch.inference_mode():
        state = predictor.init_state(video_path=img_dir_str)
        predictor.reset_state(state)

        # Add one box prompt per matched prompt, each gets a unique object id
        prompt_to_obj_id = {}
        for obj_id, (prompt, match) in enumerate(prompt_matches.items()):
            box = np.array(match["box"], dtype=np.float32)
            _, _, _ = predictor.add_new_points_or_box(
                inference_state=state,
                frame_idx=ref_idx,
                obj_id=obj_id,
                box=box,
            )
            prompt_to_obj_id[prompt] = obj_id
        obj_id_to_prompt = {v: k for k, v in prompt_to_obj_id.items()}

        # ── Propagate through all frames ──────────────────────────────────────
        cached_data = []
        prompt_counts = Counter()
        id_counts = Counter()
        id_to_prompt = {}

        print("Running video propagation...")
        for frame_idx, obj_ids, mask_logits in predictor.propagate_in_video(state):
            # mask_logits: (N_obj, 1, H, W)
            masks = (mask_logits[:, 0, :, :] > 0.0).cpu().numpy().astype(np.uint8)
            ids = np.array(obj_ids, dtype=int)

            current_ids_set = set(ids.tolist())
            for oid in current_ids_set:
                if oid in obj_id_to_prompt:
                    p_text = obj_id_to_prompt[oid]
                    prompt_counts[p_text] += 1
                    id_counts[oid] += 1
                    id_to_prompt[oid] = p_text

            cached_data.append({
                "masks": masks,
                "ids": ids,
                "frame_idx": frame_idx,
            })

    # ── Filter by min frame duration ─────────────────────────────────────────
    min_frames_id = int(np.ceil(total_frames * cfg["min_dur"]))
    final_valid_ids = {
        oid for oid, c in id_counts.items() if c >= min_frames_id
    }

    print_stats_table(
        cfg["prompts"], prompt_counts, id_to_prompt, final_valid_ids, total_frames
    )

    if not final_valid_ids:
        print("No valid IDs after frame-duration filter. Exiting.")
        return

    id_map = {
        oid: i
        for i, oid in enumerate(sorted(final_valid_ids))
        if i < 255
    }

    print(
        f"Summary: Processed {total_frames} frames. "
        f"Score > {cfg['min_score']}, "
        f"Frame Duration > {cfg['min_dur']*100:.0f}%\n"
    )
    print(f"Saving {len(final_valid_ids)} object masks...")

    for data in cached_data:
        save_mask(
            cfg["out_dir"] / files[data["frame_idx"]].name,
            data["masks"],
            data["ids"],
            id_map,
            (h, w),
        )

    print(f"[SAM2] Done. Saved to {cfg['out_dir']}")


if __name__ == "__main__":
    main()
